#define USES_CURSES
#include "gettext.h"
