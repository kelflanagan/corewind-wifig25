#ifndef CARD_SELECT_H_INCLUDED
#define CARD_SELECT_H_INCLUDED

void create_card_select_list(void);
void close_card_select_list(void);

#endif
