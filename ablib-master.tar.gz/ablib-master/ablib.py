# ablib.py 
#
# Python functions collection to easily manage the I/O lines and 
# Daisy modules with the following Acme Systems boards:
# ARIETTA G25 SoM (http://www.acmesystems.it/arietta)
# ARIAG25-EK Board (http://www.acmesystems.it/ariag25ek)
# TERRA Board (http://www.acmesystems.it/terra)
# ARIA G25 SoM (http://www.acmesystems.it/aria) 
# ACQUA A5 SoM (http://www.acmesystems.it/acqua)
# FOX Board G20 (http://www.acmesystems.it/FOXG20)
#
# (C) 2014 Sergio Tanzilli <tanzilli@acmesystems.it>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

__version__ = 'v1.0.0'

import os.path
import platform
import time
import serial
import fcntl
import struct
import thread
import threading
import select
import math

import os
import sys

if platform.platform().find("Linux-2")!=-1:
	legacy_id=True
else: 	
	legacy_id=False

redirect = open(os.devnull, 'w')
sys.stdout = redirect

serial_ports = {
	'D1' :  '/dev/ttyS2',
	'D2' :  '/dev/ttyS5',
	'D3' :  '/dev/ttyS1',
	'D5' :  '/dev/ttyS6',
	'D6' :  '/dev/ttyS4',
	'D8' :  '/dev/ttyS3',
	'D10':  '/dev/ttyS4',
	'D13':  '/dev/ttyS2',
	'D17':  '/dev/ttyS1'
}

#Pin to Kernel ID table
pin2kid = {

	#WiFIG25
		'1'		:	43,	#A/D input
		'2'		:	44, #A/D input
		'3'		:	45, #A/D input
		'4'		:	46, #A/D input
		# '5'		:		#A/D voltage reference
		'6'		:	30, #I2C bus Data
		'7'		:	31, #I2C bus Clock
		'8'		:	0,  #Serial TXD /dev/ttyS1
		'9'		:	1,	#Serial RXD /dev/ttyS1
		'10'	:	2,	#Serial RTS /dev/ttyS1
		'11'	:	3,	#Serial CTS /dev/ttyS1
		'12'	:	4,	#General purpose I/O
		'13'	:	5,	#Serial TXD /dev/ttyS2
		'14'	:	6,	#Serial RXD /dev/ttyS2
		'15'	:	7,	#Serial TXD /dev/ttyS3
		'16'	:	8,	#Serial RXD /dev/ttyS3
		'17'	:	12,	#SPI MOSI
		'18'	:	11,	#SPI MISO
		'19'	:	13,	#SPI CLOCK
		'20'	:	14,	#SPI CS0
		# '21'	:		#Ground line
		# '22'	:		#Bit banging 1-wire bus
		# '23'	:		#USB 2.0 Host full-spped port C
		# '24'	:		#USB 2.0 Host full-speed port C
		'25'	:	91,	#Serial RTS /dev/ttyS2
		'26'	:	32,	#Serial RTS /dev/ttyS3
		# '27'	:		#USB 2.0 Host/Device hi-speed port A
		# '28'	:		#USB 2.0 Host/Device hi-speed port A
		'29'	:	82,	#Pulse Width Modulation
		'30'	:	83,	#Pulse Width Modulation
		'31'	:	84,	#Pulse Width Modulation
		'32'	:	85,	#Pulse Width Modulation
		'33'	:	66,	#TC block PWM0
		'34'	:	67,	#TC block PWM1
		'35'	:	68,	#TC block CLOCK
		# '36'	:		#5V0 power in/out
		# '37'	:		#3V3 power out
		# '38'	:		#Ground line
		# '39'	:		#RTC battery in
		# '40'	:		#Reset input/output signal (active low)

	#Arietta G25
		'J4.7'   :  55, #PA23
		'J4.8'   :  54, #PA22
		'J4.10'  :  53, #PA21
		'J4.11'  :  56, #PA24
		'J4.12'  :  63, #PA31
		'J4.13'  :  57, #PA25
		'J4.14'  :  62, #PA30
		'J4.15'  :  58, #PA26
		'J4.17'  :  59, #PA27
		'J4.19'  :  60, #PA28
		'J4.21'  :  61, #PA29
		'J4.23'  :  32, #PA0
		'J4.24'  :  33, #PA1
		'J4.25'  :  40, #PA8
		'J4.26'  :  39, #PA7
		'J4.27'  :  38, #PA6
		'J4.28'  :  37, #PA5
		'J4.29'  : 124, #PC28
		'J4.30'  : 123, #PC27
		'J4.31'  : 100, #PC4
		'J4.32'  : 127, #PC31
		'J4.33'  :  99, #PC3
		'J4.34'  :  75, #PB11
		'J4.35'  :  98, #PC2
		'J4.36'  :  76, #PB12
		'J4.37'  :  97, #PC1
		'J4.38'  :  77, #PB13
		'J4.39'  :  96, #PC0
		'J4.40'  :  78, #PB14

	#Aria G25
		'N2'  :  96,
		'N3'  :  97,
		'N4'  :  98,
		'N5'  :  99,
		'N6'  : 100,
		'N7'  : 101,
		'N8'  : 102,
		'N9' :  103,
		'N10' : 104,
		'N11' : 105,
		'N12' : 106,
		'N13' : 107,
		'N14' : 108,
		'N15' : 109,
		'N16' : 110,
		'N17' : 111,
		'N18' : 112,
		'N19' : 113,
		'N20' : 114,
		'N21' : 115,
		'N22' : 116,
		'N23' : 117,
		'E2'  : 118,
		'E3'  : 119,
		'E4'  : 120,
		'E5'  : 121,
		'E6'  : 122,
		'E7'  : 123,
		'E8'  : 124,
		'E9' :  125,
		'E10' : 126,
		'E11' : 127,
		'S2'  :  53,
		'S3'  :  52,
		'S4'  :  51,
		'S5'  :  50,
		'S6'  :  49,
		'S7'  :  48,
		'S8'  :  47,
		'S9' :   46,
		'S10' :  45,
		'S11' :  44,
		'S12' :  43,
		'S13' :  42,
		'S14' :  41,
		'S15' :  40,
		'S16' :  39,
		'S17' :  38,
		'S18' :  37,
		'S19' :  36,
		'S20' :  35,
		'S21' :  34,
		'S22' :  33,
		'S23' :  32,
		'W9' :   54,
		'W10' :  55,
		'W11' :  56,
		'W12' :  57,
		'W13' :  58,
		'W14' :  59,
		'W15' :  60,
		'W16' :  61,
		'W17' :  62,
		'W18' :  63,
		'W20' :  75,
		'W21' :  76,
		'W22' :  77,
		'W23' :  78,

	#FOX Board G20
		'J7.3'  :  82,
		'J7.4'  :  83,
		'J7.5'  :  80,
		'J7.6'  :  81,
		'J7.7'  :  66,
		'J7.8'  :  67,
		'J7.9'  :  64,
		'J7.10' :  65,
		'J7.11' : 110,
		'J7.12' : 111,
		'J7.13' : 108,
		'J7.14' : 109,
		'J7.15' : 105,
		'J7.16' : 106,
		'J7.17' : 103,
		'J7.18' : 104,
		'J7.19' : 101,
		'J7.20' : 102,
		'J7.21' :  73,
		'J7.22' :  72,
		'J7.31' :  87,
		'J7.32' :  86,
		'J7.33' :  89,
		'J7.34' :  88,
		'J7.35' :  60,
		'J7.36' :  59,
		'J7.37' :  58,
		'J7.38' :  57,
		'J6.3'  :  92,
		'J6.4'  :  71,
		'J6.5'  :  70,
		'J6.6'  :  93,
		'J6.7'  :  90,
		'J6.8'  :  69,
		'J6.9'  :  68,
		'J6.10' :  91,
		'J6.13' :  75,
		'J6.14' :  74,
		'J6.15' :  77,
		'J6.16' :  76,
		'J6.17' :  85,
		'J6.18' :  84,
		'J6.19' :  95,
		'J6.20' :  94,
		'J6.21' :  63,
		'J6.22' :  62,
		'J6.24' :  38,
		'J6.25' :  39,
		'J6.26' :  41,
		'J6.27' :  99,
		'J6.28' :  98,
		'J6.29' :  97,
		'J6.30' :  96,
		'J6.31' :  56,
		'J6.32' :  55,
		'J6.36' :  42,
		'J6.37' :  54,
		'J6.38' :  43,
		
	#Daisy modules
		'D1.1' :   0, #3V3
		'D1.2' :  70, #PB6
		'D1.3' :  71, #PB7
		'D1.4' :  92, #PB28
		'D1.5' :  93, #PB29
		'D1.6' :   0, #N.C.
		'D1.7' :  55, #PA23
		'D1.8' :  56, #PA24
		'D1.9' :   0, #5V0
		'D1.10':   0, #GND
		'D2.1' :   0, #3V3
		'D2.2' :  63, #PA31
		'D2.3' :  62, #PA30
		'D2.4' :  61, #PA29
		'D2.5' :  60, #PA28
		'D2.6' :  59, #PA27
		'D2.7' :  58, #PA26
		'D2.8' :  57, #PA25
		'D2.9' :  94, #PB30
		'D2.10':   0, #GND
		'D3.1' :   0, #3V3
		'D3.2' :  68, #PB4
		'D3.3' :  69, #PB5
		'D3.4' :  90, #PB26
		'D3.5' :  91, #PB27
		'D3.6' :  86, #PB22
		'D3.7' :  88, #PB24
		'D3.8' :  89, #PB25
		'D3.9' :  87, #PB23
		'D3.10':   0, #GND
		'D4.1' :   0, #3V3
		'D4.2' :   0, #AVDD
		'D4.3' :   0, #VREF
		'D4.4' :   0, #AGND
		'D4.5' :  96, #PC0
		'D4.6' :  97, #PC1
		'D4.7' :  98, #PC2
		'D4.8' :  99, #PC3
		'D4.9' :   0, #5V0
		'D4.10':   0, #GND
		'D5.1' :   0, #3V3
		'D5.2' :  76, #PB12
		'D5.3' :  77, #PB13
		'D5.4' :  80, #PB16
		'D5.5' :  81, #PB17
		'D5.6' :  82, #PB18
		'D5.7' :  83, #PB19
		'D5.8' :  84, #PB20
		'D5.9' :  85, #PB21
		'D5.10':  0,  #GND
		'D6.1' :   0, #3V3
		'D6.2' :  74, #PB10
		'D6.3' :  75, #PB11
		'D6.4' : 104, #PC8
		'D6.5' : 106, #PC10
		'D6.6' :  95, #PB31
		'D6.7' :  55, #PA23
		'D6.8' :  56, #PA24
		'D6.9' :   0, #5V0
		'D6.10':   0, #GND
		'D7.1' :  0,  #3V3
		'D7.2' :  65, #PB1
		'D7.3' :  64, #PB0
		'D7.4' :  66, #PB2
		'D7.5' :  67, #PB3
		'D7.6' : 101, #PC5
		'D7.7' : 100, #PC4
		'D7.8' :  99, #PC3
		'D7.9' :   0, #5V0
		'D7.10':   0, #GND
		'D8.1' :   0, #3V3
		'D8.2' :  72, #PB8
		'D8.3' :  73, #PB9
		'D8.4' :   0, #N.C.
		'D8.5' :   0, #N.C.
		'D8.6' :   0, #N.C.
		'D8.7' :  55, #PA23
		'D8.8' :  56, #PA24
		'D8.9' :   0, #5V0
		'D8.10':   0, #GND
		'D10.1' :   0, #3V3
		'D10.2' : 118, #PC22
		'D10.3' : 119, #PC23
		'D10.4' : 120, #PC24
		'D10.5' : 121, #PC25
		'D10.6' : 122, #PC26
		'D10.7' :  62, #PA30
		'D10.8' :  63, #PA31
		'D10.9' :   0, #5V0
		'D10.10':   0, #GND
		'D11.1' :   0,  #3V3
		'D11.2' : 112, #PC16
		'D11.3' : 113, #PC17
		'D11.4' : 114, #PC18
		'D11.5' : 115, #PC19
		'D11.6' : 116, #PC20
		'D11.7' : 117, #PC21
		'D11.8' :  98, #PC2
		'D11.9' :  99, #PC3
		'D11.10':   0, #GND
		'D12.1' :   0, #3V3
		'D12.2' : 104, #PC8
		'D12.3' : 105, #PC9
		'D12.4' : 106, #PC10
		'D12.5' : 107, #PC11
		'D12.6' : 108, #PC12
		'D12.7' : 109, #PC13
		'D12.8' : 110, #PC14
		'D12.9' : 111, #PC15
		'D12.10':   0, #GND
		'D13.1' :   0, #3V3
		'D13.2' :  37, #PA5
		'D13.3' :  38, #PA6
		'D13.4' : 123, #PC27
		'D13.5' : 124, #PC28
		'D13.6' : 125, #PC29
		'D13.7' :  96, #PC0
		'D13.8' :  97, #PC1
		'D13.9' :   0, #5V0
		'D13.10':   0, #GND
		'D14.1' :   0, #3V3
		'D14.2' :   0, #3V3
		'D14.3' :   0, #VREF
		'D14.4' :   0, #GND
		'D14.5' :  75, #PB11
		'D14.6' :  76, #PB12
		'D14.7' :  77, #PB13
		'D14.8' :  78, #PB14
		'D14.9' :   0, #5V0
		'D14.10':   0, #GND
		'D15.1' :   0, #3V3
		'D15.2' :  44, #PA12
		'D15.3' :  43, #PA11
		'D15.4' :  45, #PA13
		'D15.5' :  46, #PA14
		'D15.6' :  39, #PA7
		'D15.7' :  33, #PA1
		'D15.8' :   0, #N.C.
		'D15.9' :   0, #5V0
		'D15.10':   0, #GND
		'D16.1' :   0, #3V3
		'D16.2' :  61, #PA29
		'D16.3' :  59, #PA27
		'D16.4' :  56, #PA24
		'D16.5' :  57, #PA25
		'D16.6' :  58, #PA26
		'D16.7' :  62, #PA30
		'D16.8' :  63, #PA31.
		'D16.9' :  60, #PA28
		'D16.10':   0, #GND
		'D17.1' :   0, #3V3
		'D17.2' :  32, #PA0
		'D17.3' :  33, #PA1
		'D17.4' :  34, #PA2
		'D17.5' :  35, #PA3
		'D17.6' :  36, #PA4
		'D17.7' :  96, #PC0
		'D17.8' :  97, #PC1
		'D17.9' :   0, #5V0
		'D10.10':   0, #GND

	#Acqua A5
		'J1.9'  :   1+32,
		'J1.10'  :   0+32,
		'J1.11'  :   3+32,
		'J1.12'  :   2+32,
		'J1.13'  :   5+32,
		'J1.14'  :   4+32,
		'J1.15'  :   7+32,
		'J1.16'  :   6+32,
		'J1.17'  :   9+32,
		'J1.18'  :   8+32,
		'J1.19'  :  11+32,
		'J1.20'  :  10+32,
		'J1.21'  :  13+32,
		'J1.22'  :  12+32,
		'J1.23'  :  15+32,
		'J1.24'  :  14+32,
		'J1.25'  :  77+32,
		'J1.26'  :  78+32,
		'J1.27'  :  75+32,
		'J1.28'  :  76+32,
		'J1.29'  :  79+32,
		'J1.30'  :  74+32,
		'J1.31'  : 156+32,
		'J1.32'  : 155+32,
		'J1.33'  :  25+32,
		'J1.35'  :  27+32,
		'J1.36'  :  28+32,
		'J1.37'  :  29+32,
		'J1.38'  :  26+32,
		'J1.39'  :  24+32,
		'J1.40'  : 116+32,
		'J1.41'  : 117+32,
		'J1.42'  : 118+32,
		'J1.43'  : 119+32,
		'J1.44'  : 120+32,
		'J1.45'  : 121+32,
		'J1.46'  : 122+32,
		'J1.47'  : 123+32,
		'J1.48'  : 124+32,
		'J1.49'  : 125+32,
		 'J2.1'  : 127+32,
		 'J2.2'  : 126+32,
		 'J2.3'  : 115+32,
		 'J2.5'  : 109+32,
		 'J2.6'  : 108+32,
		 'J2.7'  : 107+32,
		 'J2.8'  : 106+32,
		 'J2.9'  : 111+32,
		'J2.10'  : 110+32,
		'J2.11'  : 113+32,
		'J2.12'  : 112+32,
		'J2.13'  :  34+32,
		'J2.14'  : 114+32,
		'J2.15'  :  38+32,
		'J2.16'  :  35+32,
		'J2.17'  :  39+32,
		'J2.18'  :  43+32,
		'J2.19'  :  42+32,
		'J2.23'  :  36+32,
		'J2.25'  :  37+32,
		'J2.29'  :  32+32,
		'J2.31'  :  33+32,
		'J2.32'  :  46+32,
		'J2.33'  :  40+32,
		'J2.34'  :  47+32,
		'J2.35'  :  41+32,
		'J2.36'  :  48+32,
		'J2.37'  :  44+32,
		'J2.38'  :  49+32,
		'J2.39'  :  45+32,
		'J2.40'  :  50+32,
		'J2.42'  :  59+32,
		'J2.43'  :  58+32,
		'J2.44'  :  57+32,
		'J2.45'  :  60+32,
		'J2.46'  :  61+32,
		 'J3.5'  : 145+32, #PE17
		 'J3.6'  : 144+32, #PE16
		 'J3.7'  : 147+32, #PE19
		 'J3.8'  : 146+32, #PE18
		 'J3.9'  : 143+32, #PE15
		'J3.10'  : 151+32, #PE23
		'J3.11'  : 152+32, #PE24
		'J3.12'  : 153+32, #PE25
		'J3.13'  : 154+32, #PE26
		'J3.14'  : 148+32, #PE20
		'J3.15'  :  54+32, #PB22
		'J3.16'  :  55+32, #PB23
		'J3.17'  :  51+32, #PB19
		'J3.18'  :  53+32, #PB21
		'J3.19'  :  56+32, #PB24
		'J3.20'  :  52+32, #PB20
		'J3.22'  :  87+32, #PC23
		'J3.23'  :  89+32, #PC25
		'J3.24'  :  86+32, #PC22
		'J3.25'  :  88+32, #PC24
		'J3.26'  :  90+32, #PC26
		'J3.28'  :  91+32, #PC27
		'J3.29'  :  92+32, #PC28
		'J3.30'  :  94+32, #PC30
		'J3.31'  :  93+32, #PC29
		'J3.32'  :  95+32, #PC31
		'J3.33'  :  17+32, #PA17
		'J3.34'  :  16+32, #PA16
		'J3.35'  :  19+32, #PA19
		'J3.36'  :  18+32, #PA18
		'J3.37'  :  21+32, #PA21
		'J3.38'  :  20+32, #PA20
		'J3.39'  :  23+32, #PA23
		'J3.40'  :  22+32, #PA22
		'J3.41'  :  31+32, #PA31
		'J3.42'  :  30+32, #PA30
		'J3.43'  : 159+32, #PE31
		'J3.44'  : 157+32, #PE29
		'J3.45'  :  80+32, #PC16
		'J3.46'  :  81+32, #PC17
		'J3.47'  :  82+32, #PC18
		'J3.48'  :  83+32, #PC19
		'J3.49'  :  84+32, #PC20
		'J3.50'  :  85+32 #PC21
}

pinmode = {
	"OUTPUT" : "low",
	"LOW" : "low",
	"HIGH" : "high",
	"INPUT" : "in"
}

pinlevel = {
	"HIGH" : 1,
	"LOW"  : 0
}

mcuName2pinname = {
#WiFIG25
	'WiFIG25' : {
		'PB11'		:	'1',
		'PB12'		:	'2',
		'PB13'		:	'3',
		'PB14'		:	'4',
		# 'ADVREF'	:	'5',
		'PA30'		:	'6',
		'PA31'		:	'7',
		'PA0'		:	'8',
		'PA1'		:	'9',
		'PA2'		:	'10',
		'PA3'		:	'11',
		'PA4'		:	'12',
		'PA5'		:	'13',
		'PA6'		:	'14',
		'PA7'		:	'15',
		'PA8'		:	'16',
		'PA12'		:	'17',
		'PA11'		:	'18',
		'PA13'		:	'19',
		'PA14'		:	'20',
		# 'GND'		:	'21',
		# 'PB3'		:	'22',
		# 'USBCP'		:	'23',
		# 'USBCN'		:	'24',
		'PC27'		:	'25',
		'PB0'		:	'26',
		# 'USBAN'		:	'27',
		# 'USBAP'		:	'28',
		'PC18'		:	'29',
		'PC19'		:	'30',
		'PC20'		:	'31',
		'PC21'		:	'32',
		'PC2'		:	'33',
		'PC3'		:	'34',
		'PC4'		:	'35',
		# 'VDD5V'		:	'36',
		# 'VDD33'		:	'37',
		# 'GND'		:	'38',
		# 'VBAT'		:	'39',
		# 'NRST'		:	'40'
	},

#Arietta G25
    'Arietta_G25' : {
        'PA23' :  'J4.7',
        'PA22' :  'J4.8',
        'PA21' : 'J4.10',
        'PA24' : 'J4.11',
        'PA31' : 'J4.12',
        'PA25' : 'J4.13',
        'PA30' : 'J4.14',
        'PA26' : 'J4.15',
        'PA27' : 'J4.17',
        'PA28' : 'J4.19',
        'PA29' : 'J4.21',
         'PA0' : 'J4.23',
         'PA1' : 'J4.24',
         'PA8' : 'J4.25',
         'PA7' : 'J4.26',
         'PA6' : 'J4.27',
         'PA5' : 'J4.28',
        'PC28' : 'J4.29',
        'PC27' : 'J4.30',
         'PC4' : 'J4.31',
        'PC31' : 'J4.32',
         'PC3' : 'J4.33',
        'PB11' : 'J4.34',
         'PC2' : 'J4.35',
        'PB12' : 'J4.36',
         'PC1' : 'J4.37',
        'PB13' : 'J4.38',
         'PC0' : 'J4.39',
        'PB14' : 'J4.40'
        },

#Daisy modules
    'Daisy' : {
		'PB6' :  'D1.2',
		'PB7' :  'D1.3',
		'PB28' :  'D1.4',
		'PB29' :  'D1.5',
		'PA23' :  'D1.7',
		'PA24' :  'D1.8',
		'PA31' :  'D2.2',
		'PA30' :  'D2.3',
		'PA29' :  'D2.4',
		'PA28' :  'D2.5',
		'PA27' :  'D2.6',
		'PA26' :  'D2.7',
		'PA25' :  'D2.8',
		'PB30' :  'D2.9',
		'PB4' :  'D3.2',
		'PB5' :  'D3.3',
		'PB26' :  'D3.4',
		'PB27' :  'D3.5',
		'PB22' :  'D3.6',
		'PB24' :  'D3.7',
		'PB25' :  'D3.8',
		'PB23' :  'D3.9',
		'PC0' :  'D4.5',
		'PC1' :  'D4.6',
		'PC2' :  'D4.7',
		'PC3' :  'D4.8',
		'PB12' :  'D5.2',
		'PB13' :  'D5.3',
		'PB16' :  'D5.4',
		'PB17' :  'D5.5',
		'PB18' :  'D5.6',
		'PB19' :  'D5.7',
		'PB20' :  'D5.8',
		'PB21' :  'D5.9',
		'PB10' :  'D6.2',
		'PB11' :  'D6.3',
		'PC8' :  'D6.4',
		'PC10' :  'D6.5',
		'PB31' :  'D6.6',
		'PA23' :  'D6.7',
		'PA24' :  'D6.8',
		'PB1' :  'D7.2',
		'PB0' :  'D7.3',
		'PB2' :  'D7.4',
		'PB3' :  'D7.5',
		'PC5' :  'D7.6',
		'PC4' :  'D7.7',
		'PC3' :  'D7.8',
		'PB8' :  'D8.2',
		'PB9' :  'D8.3',
		'PA23' :  'D8.7',
		'PA24' :  'D8.8',
		'PC22' : 'D10.2',
		'PC23' : 'D10.3',
		'PC24' : 'D10.4',
		'PC25' : 'D10.5',
		'PC26' : 'D10.6',
		'PA30' : 'D10.7',
		'PA31' : 'D10.8',
		'PC16' : 'D11.2',
		'PC17' : 'D11.3',
		'PC18' : 'D11.4',
		'PC19' : 'D11.5',
		'PC20' : 'D11.6',
		'PC21' : 'D11.7',
		'PC2' : 'D11.8',
		'PC3' : 'D11.9',
		'PC8' : 'D12.2',
		'PC9' : 'D12.3',
		'PC10' : 'D12.4',
		'PC11' : 'D12.5',
		'PC12' : 'D12.6',
		'PC13' : 'D12.7',
		'PC14' : 'D12.8',
		'PC15' : 'D12.9',
		'PA5' : 'D13.2',
		'PA6' : 'D13.3',
		'PC27' : 'D13.4',
		'PC28' : 'D13.5',
		'PC29' : 'D13.6',
		'PC0' : 'D13.7',
		'PC1' : 'D13.8',
		'PB11' : 'D14.5',
		'PB12' : 'D14.6',
		'PB13' : 'D14.7',
		'PB14' : 'D14.8',
		'PA12' : 'D15.2',
		'PA11' : 'D15.3',
		'PA13' : 'D15.4',
		'PA14' : 'D15.5',
		'PA7' : 'D15.6',
		'PA1' : 'D15.7',
		'PA29' : 'D16.2',
		'PA27' : 'D16.3',
		'PA24' : 'D16.4',
		'PA25' : 'D16.5',
		'PA26' : 'D16.6',
		'PA30' : 'D16.7',
		'PA31' : 'D16.8',
		'PA28' : 'D16.9',
		'PA0' : 'D17.2',
		'PA1' : 'D17.3',
		'PA2' : 'D17.4',
		'PA3' : 'D17.5',
		'PA4' : 'D17.6',
		'PC0' : 'D17.7',
		'PC1' : 'D17.8'
    },
    
#Acqua A5
    'Acqua_A5' : {
		'PA1' :  'J1.9',
		'PA0' : 'J1.10',
		'PA3' : 'J1.11',
		'PA2' : 'J1.12',
		'PA5' : 'J1.13',
		'PA4' : 'J1.14',
		'PA7' : 'J1.15',
		'PA6' : 'J1.16',
		'PA9' : 'J1.17',
		'PA8' : 'J1.18',
        'PA11' : 'J1.19',
        'PA10' : 'J1.20',
        'PA13' : 'J1.21',
        'PA12' : 'J1.22',
        'PA15' : 'J1.23',
        'PA14' : 'J1.24',
        'PC13' : 'J1.25',
        'PC14' : 'J1.26',
        'PC11' : 'J1.27',
        'PC12' : 'J1.28',
        'PC15' : 'J1.29',
        'PC10' : 'J1.30',
        'PE28' : 'J1.31',
        'PE27' : 'J1.32',
        'PA25' : 'J1.33',
        'PA27' : 'J1.35',
        'PA28' : 'J1.36',
        'PA29' : 'J1.37',
        'PA26' : 'J1.38',
        'PA24' : 'J1.39',
        'PD20' : 'J1.40',
        'PD21' : 'J1.41',
        'PD22' : 'J1.42',
        'PD23' : 'J1.43',
        'PD24' : 'J1.44',
        'PD25' : 'J1.45',
        'PD26' : 'J1.46',
        'PD27' : 'J1.47',
        'PD28' : 'J1.48',
        'PD29' : 'J1.49',

        'PD31' :  'J2.1',
        'PD30' :  'J2.2',
        'PD19' :  'J2.3',
        'PD13' :  'J2.5',
        'PD12' :  'J2.6',
        'PD11' :  'J2.7',
        'PD10' :  'J2.8',
        'PD15' :  'J2.9',
        'PD14' : 'J2.10',
        'PD17' : 'J2.11',
        'PD16' : 'J2.12',
         'PB2' : 'J2.13',
        'PD18' : 'J2.14',
         'PB6' : 'J2.15',
         'PB3' : 'J2.16',
         'PB7' : 'J2.17',
        'PB11' : 'J2.18',
        'PB10' : 'J2.19',
         'PB4' : 'J2.23',
         'PB5' : 'J2.25',
         'PB0' : 'J2.29',
         'PB1' : 'J2.31',
        'PB14' : 'J2.32',
         'PB8' : 'J2.33',
        'PB15' : 'J2.34',
         'PB9' : 'J2.35',
        'PB16' : 'J2.36',
        'PB12' : 'J2.37',
        'PB17' : 'J2.38',
        'PB13' : 'J2.39',
        'PB18' : 'J2.40',
        'PB27' : 'J2.42',
        'PB26' : 'J2.43',
        'PB25' : 'J2.44',
        'PB28' : 'J2.45',
        'PB29' : 'J2.46',

        'PE17' :  'J3.5',
        'PE16' :  'J3.6',
        'PE19' :  'J3.7',
        'PE18' :  'J3.8',
        'PE15' :  'J3.9',
        'PE23' : 'J3.10',
        'PE24' : 'J3.11',
        'PE25' : 'J3.12',
        'PE26' : 'J3.13',
        'PE20' : 'J3.14',
        'PB22' : 'J3.15',
        'PB23' : 'J3.16',
        'PB19' : 'J3.17',
        'PB21' : 'J3.18',
        'PB24' : 'J3.19',
        'PB20' : 'J3.20',
        'PC23' : 'J3.22',
        'PC25' : 'J3.23',
        'PC22' : 'J3.24',
        'PC24' : 'J3.25',
        'PC26' : 'J3.26',
        'PC27' : 'J3.28',
        'PC28' : 'J3.29',
        'PC30' : 'J3.30',
        'PC29' : 'J3.31',
        'PC31' : 'J3.32',
        'PA17' : 'J3.33',
        'PA16' : 'J3.34',
        'PA19' : 'J3.35',
        'PA18' : 'J3.36',
        'PA21' : 'J3.37',
        'PA20' : 'J3.38',
        'PA23' : 'J3.39',
        'PA22' : 'J3.40',
        'PA31' : 'J3.41',
        'PA30' : 'J3.42',
        'PE31' : 'J3.43',
        'PE29' : 'J3.44',
        'PC16' : 'J3.45',
        'PC17' : 'J3.46',
        'PC18' : 'J3.47',
        'PC19' : 'J3.48',
        'PC20' : 'J3.49',
        'PC21' : 'J3.50'
    }
}

def getVersion ():
	return __version__

def get_gpio_path(kernel_id):
	global legacy_id
	kernel_id=kernel_id-32
	legacy_id = True
	
	if (legacy_id==True):
		iopath="/sys/class/gpio/gpio%d" % (kernel_id+32)
		
	if (legacy_id==False):
		iopath="/sys/class/gpio/pio" 
		if kernel_id>=0 and kernel_id<=31:
			iopath="%sA%d" % (iopath,kernel_id-0)
		if kernel_id>=32 and kernel_id<=63:
			iopath="%sB%d" % (iopath,kernel_id-32)
		if kernel_id>=64 and kernel_id<=95:
			iopath="%sC%d" % (iopath,kernel_id-64)
		if kernel_id>=96 and kernel_id<=127:
			iopath="%sD%d" % (iopath,kernel_id-96)
		if kernel_id>=128 and kernel_id<=159:
			iopath="%sE%d" % (iopath,kernel_id-128)
	print "iopath: {}".format(iopath)
	return iopath		

def get_kernel_id(connector_name,pin_number):
	return pinname2kernelid(connector_name + "." +pin_number)

def export(kernel_id):
	global legacy_id
	iopath=get_gpio_path(kernel_id)
	if not os.path.exists(iopath): 
		f = open('/sys/class/gpio/export','w')
		if (legacy_id==True):
			f.write(str(kernel_id))
		else:
			f.write(str(kernel_id-32))
		f.close()

def unexport(kernel_id):
	global legacy_id

	iopath=get_gpio_path(kernel_id)
	if os.path.exists(iopath): 
		f = open('/sys/class/gpio/unexport','w')
		if (legacy_id==True):
			f.write(str(kernel_id))
		else:
			f.write(str(kernel_id-32))
		f.close()

def direction(kernel_id,direct):
	iopath=get_gpio_path(kernel_id)
	if os.path.exists(iopath): 
		f = open(iopath + '/direction','w')
		f.write(direct)
		f.close()

def set_value(kernel_id,value):
	iopath=get_gpio_path(kernel_id)
	if os.path.exists(iopath): 
		f = open(iopath + '/value','w')
		f.write(str(value))
		f.close()

def get_value(kernel_id):
	if kernel_id<>-1:
		iopath=get_gpio_path(kernel_id)
		if os.path.exists(iopath): 
			f = open(iopath + '/value','r')
			a=f.read()
			f.close()
			return int(a)

def set_edge(kernel_id,value):
	iopath=get_gpio_path(kernel_id)
	if os.path.exists(iopath): 
		if value in ('none', 'rising', 'falling', 'both'):
		    f = open(iopath + '/edge','w')
		    f.write(value)
		    f.close()

def soft_pwm_export(kernel_id):
	iopath='/sys/class/soft_pwm/pwm' + str(kernel_id)
	if not os.path.exists(iopath): 
		f = open('/sys/class/soft_pwm/export','w')
		f.write(str(kernel_id))
		f.close()

def soft_pwm_period(kernel_id,value):
	iopath='/sys/class/soft_pwm/pwm' + str(kernel_id)
	if os.path.exists(iopath): 
		f = open(iopath + '/period','w')
		f.write(str(value))
		f.close()

def soft_pwm_pulse(kernel_id,value):
	iopath='/sys/class/soft_pwm/pwm' + str(kernel_id)
	if os.path.exists(iopath): 
		f = open(iopath + '/pulse','w')
		f.write(str(value))
		f.close()

def soft_pwm_steps(kernel_id,value):
	iopath='/sys/class/soft_pwm/pwm' + str(kernel_id)
	if os.path.exists(iopath): 
		f = open(iopath + '/pulses','w')
		f.write(str(value))
		f.close()

def pinname2kernelid(pinname):
	"""
	Return the Kernel ID of any Pin using the MCU name
	or the board name
	"""

	offset=-1
	if pinname[0:2]=="PA":
		offset=32+0
	if pinname[0:2]=="PB":
		offset=32+32
	if pinname[0:2]=="PC":
		offset=32+64
	if pinname[0:2]=="PD":
		offset=32+96
	if pinname[0:2]=="PE":
		offset=32+128

	if offset!=-1:
		return offset+int(pinname[2:4])
	else:	
		return pin2kid[pinname]

def readU8(bus,address,reg):
  result = bus.read_byte_data(address, reg)
  return result

def readS8(bus,address,reg):
	result = bus.read_byte_data(address, reg)
	if result > 127: 
		result -= 256
	return result

def readS16(bus,address,register):
	hi = readS8(bus,address,register)
	lo = readU8(bus,address,register+1)
	return (hi << 8) + lo

def readU16(bus,address,register):
	hi = readU8(bus,address,register)
	lo = readU8(bus,address,register+1)
	return (hi << 8) + lo

def write8(bus,address,reg,value):
	bus.write_byte_data(address,reg,value)

class Pin():
	"""
	FOX and AriaG25 pins related class
	"""
	kernel_id=None
	fd=None


	def __init__(self,pin,mode):
		self.kernel_id=pinname2kernelid(pin)
		export(self.kernel_id)
		direction(self.kernel_id,pinmode[mode])

		iopath=get_gpio_path(self.kernel_id)
		if os.path.exists(iopath): 
			self.fd = open(iopath + '/value','r')

	def high(self):
		set_value(self.kernel_id,1)
		
	def low(self):
		set_value(self.kernel_id,0)

	def on(self):
		set_value(self.kernel_id,1)
		
	def off(self):
		set_value(self.kernel_id,0)

	def digitalWrite(self,level):
		set_value(self.kernel_id,pinlevel[level])

	def set_value(self,value):
		return set_value(self.kernel_id,value)

	def digitalRead(self):
		return get_value(self.kernel_id)

	def get_value(self):
		return get_value(self.kernel_id)

	get = get_value

	def wait_edge(self,fd,callback,debouncingtime):
		debouncingtime=debouncingtime/1000.0 # converto in millisecondi
		timestampprec=time.time()
		counter=0
		po = select.epoll()
		po.register(fd,select.EPOLLET)
		while True:
			events = po.poll()
			timestamp=time.time()
			if (timestamp-timestampprec>debouncingtime) and counter>0:
				callback()
			counter=counter+1
			timestampprec=timestamp

	def set_edge(self,value,callback,debouncingtime=0):
		if self.fd!=None:
			set_edge(self.kernel_id,value)
			thread.start_new_thread(self.wait_edge,(self.fd,callback,debouncingtime))
			return
		else:		
			thread.exit()

#--------------------------------------------------------------

w1path = "/sys/bus/w1/devices/w1 bus master"

def w1buslist():
	if not os.path.exists(w1path): 
		print "1-wire bus not found"
		print "Check if the 1-wire bus is installed"
		return

	deviceList = os.listdir(w1path)
	#		for deviceId in deviceList:
	#			print deviceId

	return [deviceId[3:] for deviceId in deviceList if deviceId[0:2]=="28"]

class DS18B20():

	sensor_path=""

	def __init__(self,w1Id):
		if not os.path.exists(w1path): 
			print "1-wire bus not found"
			return

		self.sensor_path = os.path.join(w1path,"28-" + w1Id)

		if not os.path.exists(self.sensor_path): 
			print "Sensor %s not found" % (w1Id)
			return

		#		print self.sensor_path

	def getTemp(self):

		f = open(self.sensor_path + '/w1_slave','r')
		tString=f.read()
		f.close()

		if tString.find("NO")>=0:
			print "Wrong CRC"
			return
			
		p=tString.find("t=")
		return float(tString[p+2:-1])/1000

class DS28EA00():

	sensor_path=""

	def __init__(self,w1Id):
		if not os.path.exists(w1path): 
			print "1-wire bus not found"
			return

		self.sensor_path = os.path.join(w1path,"42-" + w1Id)

		if not os.path.exists(self.sensor_path): 
			print "Sensor %s not found" % (w1Id)
			return

		#		print self.sensor_path

	def getTemp(self):

		f = open(self.sensor_path + '/therm','r')
		tString=f.read()
		f.close()

		if tString.find("NO")>=0:
			print "Wrong CRC"
			return
			
		p=tString.find("t=")
		return float(tString[p+2:-1])

